﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Linq;

namespace ValidateCustomeIdPDF
{
    class Program
    {
        static void Main(string[] args)
        {
           
            DataSet ds_cust_xml = new DataSet();
            ds_cust_xml.ReadXml(@"C:\Users\arda274559\Desktop\ASR\oldarxml_output\BsWm_New\BswM_4.1.3.xml");

            DataTable customerTable = ds_cust_xml.Tables["General"];

            List<string> ids = new List<string>(customerTable.Rows.Count);

            customerTable.DefaultView.Sort = "CustId";
            customerTable = customerTable.DefaultView.ToTable();

            foreach (DataRow row in customerTable.Rows)
            {

                ids.Add((string)row["CustId"]);
            }

            TextWriter tw = new StreamWriter(@"C:\Users\arda274559\Desktop\ASR\Output_compare\xml.txt");

            foreach (String s in ids)
                tw.WriteLine(s);

            tw.Close();



            DataSet ds_arxml = new DataSet();
            ds_arxml.ReadXml(@"C:\Users\arda274559\Desktop\ASR\oldarxml_output\BsWm_Old\BswM_4.1.3.xml");
           
            DataTable customerTableOld = ds_arxml.Tables["General"];

            List<string> oldIds = new List<string>(customerTableOld.Rows.Count);

            customerTableOld.DefaultView.Sort = "CustId";
            customerTableOld = customerTableOld.DefaultView.ToTable();        
          
            foreach (DataRow row in customerTableOld.Rows)
            {

                oldIds.Add((string)row["CustId"]);
            }

            TextWriter tw1 = new StreamWriter(@"C:\Users\arda274559\Desktop\ASR\Output_compare\arxml.txt");

            foreach (String s in oldIds)
                tw1.WriteLine(s);

            tw1.Close();

            IEnumerable<string> firstDiffSecond = ids.Where(item => !oldIds.Contains(item));

  
            foreach (var id in firstDiffSecond)
            {
                Console.WriteLine("Ids which are not in arxml : " + id);
            }
            Console.WriteLine("\nCount of Ids which are not in arxml : " + firstDiffSecond.Count());

            Console.WriteLine("\n");
            IEnumerable<string> secondDiffFirst = oldIds.Where(item1 => !ids.Contains(item1));
            foreach (var id1 in secondDiffFirst)
            {

                Console.WriteLine("Ids which are not in xml : " + id1);
            }

            Console.WriteLine("\nCount of Ids which are not in xml : " + secondDiffFirst.Count());
            Console.WriteLine("\n");
            int count = ids.Count();

            int countOld = oldIds.Count();

                Console.WriteLine("Customer ID count for " + "pdf is:" + count + "  and arxml is:" + countOld);


           



            Console.ReadKey();
        }
    }
}
